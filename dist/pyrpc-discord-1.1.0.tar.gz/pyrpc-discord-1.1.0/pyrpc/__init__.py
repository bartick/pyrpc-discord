# Version of Module

__title__ = 'pyrpc'
__author__ = 'bartick'
__copyright__ = 'Copyright 2021 bartick'
__license__ = 'MIT'
__version__ = '1.1.0'